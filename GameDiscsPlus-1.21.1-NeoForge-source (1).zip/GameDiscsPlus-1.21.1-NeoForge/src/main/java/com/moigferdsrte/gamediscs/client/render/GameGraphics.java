package com.moigferdsrte.gamediscs.client.render;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.FormattedCharSequence;

/** Minecraft 1.21.1 adapter for the mini-games' drawing operations. */
public final class GameGraphics {
    private final GuiGraphics delegate;

    public GameGraphics(GuiGraphics delegate) { this.delegate = delegate; }

    public void drawTexture(ResourceLocation texture, int x, int y, int z, float u, float v,
                            int width, int height, int textureWidth, int textureHeight) {
        delegate.blit(texture, x, y, z, u, v, width, height, textureWidth, textureHeight);
    }

    public void drawTexture(ResourceLocation texture, int x, int y, int z, float u, float v,
                            int width, int height, int sourceWidth, int sourceHeight,
                            int textureWidth, int textureHeight) {
        delegate.blit(texture, x, y, z, u, v, width, height, sourceWidth, sourceHeight,
                textureWidth, textureHeight);
    }

    public void drawText(Font font, Component text, int x, int y, int color, boolean shadow) {
        delegate.drawString(font, text, x, y, opaqueArgb(color), shadow);
    }

    public void drawText(Font font, String text, int x, int y, int color, boolean shadow) {
        delegate.drawString(font, text, x, y, opaqueArgb(color), shadow);
    }

    public void drawScaledText(Font font, Component text, float x, float y, int color, boolean shadow, float scale) {
        drawScaledText(font, text.getVisualOrderText(), x, y, color, shadow, scale);
    }

    public void drawScaledText(Font font, FormattedCharSequence text, float x, float y, int color, boolean shadow, float scale) {
        if (scale <= 0.0F) return;
        PoseStack pose = delegate.pose();
        pose.pushPose();
        try {
            pose.translate(x, y, 0.0F);
            pose.scale(scale, scale, 1.0F);
            delegate.drawString(font, text, 0, 0, opaqueArgb(color), shadow);
        } finally { pose.popPose(); }
    }

    public void drawRotatedSprite(TextureAtlasSprite sprite, float centerX, float centerY, float size, float angle) {
        int drawSize = Math.max(1, Math.round(size));
        PoseStack pose = delegate.pose();
        pose.pushPose();
        try {
            pose.translate(centerX, centerY, 0.0F);
            pose.mulPose(Axis.ZP.rotation(angle));
            delegate.blit(0, -drawSize / 2, -drawSize / 2, drawSize, drawSize, sprite);
        } finally { pose.popPose(); }
    }

    public void drawRotatedTexture(ResourceLocation texture, float centerX, float centerY, float width,
                                  float height, float angle, int textureWidth, int textureHeight) {
        int drawWidth = Math.max(1, Math.round(width));
        int drawHeight = Math.max(1, Math.round(height));
        PoseStack pose = delegate.pose();
        pose.pushPose();
        try {
            pose.translate(centerX, centerY, 0.0F);
            pose.mulPose(Axis.ZP.rotation(angle));
            delegate.blit(texture, -drawWidth / 2, -drawHeight / 2, 0, 0, 0,
                    drawWidth, drawHeight, textureWidth, textureHeight);
        } finally { pose.popPose(); }
    }

    /** Layer extraction is not part of the 1.21.1 immediate GUI API. */
    public void nextStratum() { }
    public void enableScissor(int x0, int y0, int x1, int y1) { delegate.enableScissor(x0, y0, x1, y1); }
    public void disableScissor() { delegate.disableScissor(); }

    private static int opaqueArgb(int color) {
        return (color & 0xFF000000) == 0 ? color | 0xFF000000 : color;
    }
}
