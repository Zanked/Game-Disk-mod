# GameDiscs Plus — NeoForge port (Minecraft 1.21.1)

Unofficial porting workspace for **Minecraft 1.21.1**, **NeoForge 21.1.x**, and **Java 21**.

## Build

1. Install a 64-bit JDK 21.
2. Clone/download this repository.
3. Run `./gradlew build` on Linux/macOS or `gradlew.bat build` on Windows.
4. If the build succeeds, the mod JAR is in `build/libs/`.

The GitHub Actions workflow builds on pushes and pull requests and uploads `build/libs/*.jar` as an artifact. The first CI build is the authoritative compilation check; this workspace could not download the Gradle distribution in its current environment because outbound DNS/network access is blocked.

## Status / limitations

This is a **work-in-progress port**, not yet a verified release. Item, sound, and creative-tab registration have been moved to NeoForge deferred registries. Client screen rendering and Minecraft 1.21.1 API compatibility still need to be verified by the CI build and an in-game test. The original Fabric loot-table callback has not been fully ported, so the original bonus drops from chests/mobs are not yet guaranteed to work.

Please open the Actions tab after pushing this project and fix any compiler errors shown by the first build. Do not publish the resulting JAR as a release until it has been tested in a 1.21.1 NeoForge client and dedicated server.

## Mod metadata

- Mod ID: `gamediscs`
- Minecraft: `1.21.1`
- NeoForge: `21.1.x`
- Java: `21`
