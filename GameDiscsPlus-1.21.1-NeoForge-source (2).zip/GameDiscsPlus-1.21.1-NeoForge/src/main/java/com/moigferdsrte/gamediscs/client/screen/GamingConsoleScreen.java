package com.moigferdsrte.gamediscs.client.screen;

import net.minecraft.client.Minecraft;
import com.moigferdsrte.gamediscs.client.render.GameGraphics;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.world.entity.player.Player;
import net.minecraft.network.chat.Component;
import net.minecraft.ChatFormatting;
import net.minecraft.resources.ResourceLocation;
import com.moigferdsrte.gamediscs.GameDiscs;
import com.moigferdsrte.gamediscs.client.ClientUtils;
import com.moigferdsrte.gamediscs.games.controls.Button;
import com.moigferdsrte.gamediscs.games.util.Game;
import com.moigferdsrte.gamediscs.item.custom.GameDiscItem;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public final class GamingConsoleScreen extends Screen {
    private static final ResourceLocation BACKGROUND = ResourceLocation.fromNamespaceAndPath(GameDiscs.MOD_ID, "textures/gui/gaming_console.png");
    private static final int CONSOLE_WIDTH = 160;
    private static final int CONSOLE_HEIGHT = 198;

    private static final int SCREEN_X = 10;
    private static final int SCREEN_Y = 10;

    private static final int W = InputConstants.KEY_W;
    private static final int S = InputConstants.KEY_S;
    private static final int A = InputConstants.KEY_A;
    private static final int D = InputConstants.KEY_D;
    private static final int SPACE = InputConstants.KEY_SPACE;
    private static final int ENTER = InputConstants.KEY_RETURN;
    private static final int Q = InputConstants.KEY_Q;
    private static final int R = InputConstants.KEY_R;

    // Minecraft 1.21.1 uses GLFW key codes in Screen key callbacks.
    // Visual buttons that allow you to visually see if the button is pressed or not
    private static final VisualButton W_BUTTON = new VisualButton(BACKGROUND, 256, 256, 33, 121, 14, 24, 183, 0, 24);
    private static final VisualButton A_BUTTON = new VisualButton(BACKGROUND, 256, 256, 17, 137, 23, 15, 160, 0, 24);
    private static final VisualButton D_BUTTON = new VisualButton(BACKGROUND, 256, 256, 40, 137, 23, 15, 197, 0, 24);
    private static final VisualButton S_BUTTON = new VisualButton(BACKGROUND, 256, 256, 33, 145, 14, 23, 220, 0, 24);
    private static final VisualButton B1_BUTTON = new VisualButton(BACKGROUND, 256, 256, 96, 136, 16, 16, 234, 0, 24);
    private static final VisualButton B2_BUTTON = new VisualButton(BACKGROUND, 256, 256, 128, 128, 16, 16, 234, 0, 24);

    // Calculates position of the console on screen
    private int getConsoleX() {
        return (this.width - CONSOLE_WIDTH) / 2;
    }
    private int getConsoleY() {
        return (this.height - CONSOLE_HEIGHT) / 2;
    }

    // List of games that are available to play
    private final List<Game> availableGames;

    // Currently selected game
    private int selected = 0;

    // Game, the player is currently playing (if there is only Game, and not its child, it means there is no game selected, and game selection screen is showed)
    private Game game = new Game();

    public GamingConsoleScreen(Component title) {
        super(title);

        // Scans for games in player's inventory
        availableGames = scanForGames();
    }

    // This screen doesn't pause the game when opened
    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void tick() {
        game.tick();
    }

    @Override
    public void render(GuiGraphics extractor, int mouseX, int mouseY, float partialTick) {
        super.render(extractor, mouseX, mouseY, partialTick);
        GameGraphics graphics = new GameGraphics(extractor);
        renderMyBackground(graphics);
        renderGameScreen(graphics, getConsoleX() + SCREEN_X, getConsoleY() + SCREEN_Y);
        renderButtons(graphics);
    }

    private void renderMyBackground(GameGraphics context) {
        context.drawTexture(BACKGROUND, getConsoleX(), getConsoleY(), 0, 0, 0, CONSOLE_WIDTH, CONSOLE_HEIGHT, 256, 256);
    }

    /**
     * Renders game screen, including game, game selection, scores, etc.
     * @param graphics GameGraphics used for rendering
     * @param x X position of the game screen
     * @param y Y position of the game screen
     */
    private void renderGameScreen(GameGraphics graphics, int x, int y) {
        // Makes sure that nothing is rendered outside the game screen
        graphics.enableScissor(x, y, x + Game.WIDTH, y + Game.HEIGHT);

        // Renders the game itself
        if (!game.isEmpty()) {
            game.render(graphics, x, y);
            // 26.2 提取式渲染需要独立层级，才能保证结算画面高于游戏实体。
            graphics.nextStratum();
            game.renderOverlay(graphics, x, y);
        }
        else {
            // If the game is empty, renders game selection screen
            renderGameSelection(graphics, x, y);
        }

        // Allowing rendering everywhere
        graphics.disableScissor();
    }

    /**
     * Renders game selection screen
     * @param graphics GameGraphics used for rendering
     * @param x X position
     * @param y Y position
     */
    private void renderGameSelection(GameGraphics graphics, int x, int y) {
        // If there are some available games, it renders a selection marking on corresponding Y position
        if (!availableGames.isEmpty()) {
            graphics.drawTexture(
                    ResourceLocation.fromNamespaceAndPath(GameDiscs.MOD_ID, "textures/gui/selected.png"),
                    x,
                    y + 3 + font.lineHeight + 18 * selected - (Math.max(0, selected - 3) * 18),
                    0, 0, 0, 140, 18, 140, 18
            );
        } else {
            graphics.drawText(
                    font,
                    Component.translatable("gui.gamingconsole.no_selectable_game").withStyle(ChatFormatting.ITALIC),
                    x + (Game.WIDTH - font.width(Component.translatable("gui.gamingconsole.no_selectable_game").withStyle(ChatFormatting.BOLD).getVisualOrderText())) / 2,
                    y + 26,
                    0xace53b,
                    false
            );
        }

        // Rendering "Select game" title, on top of the screen
        graphics.drawText(
                font,
                Component.translatable("gui.gamingconsole.select_game").withStyle(ChatFormatting.BOLD),
                x + (Game.WIDTH - font.width(Component.translatable("gui.gamingconsole.select_game").withStyle(ChatFormatting.BOLD).getVisualOrderText())) / 2,
                y + 3 - (Math.max(0, selected - 3) * 18),
                0xace53b,
                false
        );

        // Rendering all available games
        for (int i = 0; i < availableGames.size(); i++) {
            // Rendering name of the game
            graphics.drawText(
                    font,
                    // If the game is currently selected, the title renders bold
                    Component.literal(availableGames.get(i).getName().getString()).withStyle(i == selected ? ChatFormatting.BOLD : ChatFormatting.ITALIC),
                    x + 22,
                    y + 4 + font.lineHeight + 18 * i + (18 - font.lineHeight) / 2 - (Math.max(0, selected - 3) * 18),
                    0xFFAA00,
                    false
            );
            // Rendering icon of the game
            graphics.drawTexture(
                    availableGames.get(i).getIcon(),
                    x + 3,
                    y + 4 + font.lineHeight + 18 * i - (Math.max(0, selected - 3) * 18),
                    0, 0, 0, 16, 16, 16, 16
            );
        }
    }

    /**
     * Renders all visual buttons
     * @param graphics GameGraphics used for rendering
     */
    private void renderButtons(GameGraphics graphics) {
        W_BUTTON.render(graphics, getConsoleX(), getConsoleY(), game.controls.isButtonDown(Button.UP));
        A_BUTTON.render(graphics, getConsoleX(), getConsoleY(), game.controls.isButtonDown(Button.LEFT));
        D_BUTTON.render(graphics, getConsoleX(), getConsoleY(), game.controls.isButtonDown(Button.RIGHT));
        S_BUTTON.render(graphics, getConsoleX(), getConsoleY(), game.controls.isButtonDown(Button.DOWN));
        B1_BUTTON.render(graphics, getConsoleX(), getConsoleY(), game.controls.isButtonDown(Button.BUTTON1));
        B2_BUTTON.render(graphics, getConsoleX(), getConsoleY(), game.controls.isButtonDown(Button.BUTTON2));
    }

    /**
     * Scans for all games, player currently has in inventory
     * @return List of found games
     */
    public List<Game> scanForGames() {
        // Creating the list of the games
        List<Game> games = new ArrayList<>();
        Player player = Objects.requireNonNull(Minecraft.getInstance().player);

        // Going through each slot of player's inventory
        for (int i = 0; i < player.getInventory().getContainerSize(); i++) {
            // If the item is GameDisc, it creates the Game and adds it to the list
            if (player.getInventory().getItem(i).getItem() instanceof GameDiscItem disc) {
                games.add(ClientUtils.newGameFor(disc));
            }
        }

        return games;
    }

    // Main method for pressed keys
    @Override
    public boolean keyPressed(int key, int scanCode, int modifiers) {
        // This method should return true if the key press was consumed. So it saves it in this flag variable
        boolean flag = false;

        // If the game is not empty, tries to quit or reset the game if the corresponding key was pressed
        if (!game.isEmpty()) {
            // If the key was Q, returns to game selection (sets game to empty Game)
            if (key == Q) {
                game = new Game();
                flag = true;
                game.soundPlayer.playConfirm();
            }
            // If the key was R, resets the game by calling prepare() method
            else if (key == R) {
                game.prepare();
                flag = true;
                game.soundPlayer.playConfirm();
            }
        }
        else {
            if (key == Q) {
                this.minecraft.setScreen(null);
                return true;
            }
        }
        if (game != null) {
            // Sets the button in game's controls to pressed state if a control key was pressed.
            Button button = buttonForKey(key);
            if (button != null) {
                game.controls.setButton(button, true);
                flag = true;
            }
        }
        if (game.isEmpty()) {
            // If we are in game selection, it must handle the keys by itself
            // W moves the selection up
            if (key == W && !availableGames.isEmpty()) {
                int newSelected = selected - 1;
                if (newSelected < 0) {
                    newSelected = availableGames.size() - 1;
                }
                selected = newSelected;
                flag = true;
                game.soundPlayer.playSelect();
            }
            // S moves the selection down
            if (key == S && !availableGames.isEmpty()) {
                int newSelected = selected + 1;
                if (newSelected > availableGames.size() - 1) {
                    newSelected = 0;
                }
                selected = newSelected;
                flag = true;
                game.soundPlayer.playSelect();
            }
            // Space selects game
            if ((key == SPACE || key == ENTER) && !availableGames.isEmpty()) {
                Game newGame = availableGames.get(selected);
                newGame.prepare();
                game = newGame;
                flag = true;
                game.soundPlayer.playConfirm();
            }
        }
        return super.keyPressed(key, scanCode, modifiers) || flag;
    }

    // Main method for handling key releasing
    @Override
    public boolean keyReleased(int key, int scanCode, int modifiers) {
        // This method should return true if the key release was consumed, so it saves it in this flag variable
        boolean flag = false;

        if (game != null) {
            Button button = buttonForKey(key);
            if (button != null) {
                game.controls.setButton(button, false);
                flag = true;
            }
        }
        return super.keyReleased(key, scanCode, modifiers) || flag;
    }

    /**
     * Maps a 26.3 keyboard scancode to the console's virtual buttons.
     *
     * @param key GLFW key code
     * @return the matching virtual button, or {@code null} for non-control keys
     */
    static Button buttonForKey(int key) {
        return switch (key) {
            case W -> Button.UP;
            case S -> Button.DOWN;
            case A -> Button.LEFT;
            case D -> Button.RIGHT;
            case SPACE -> Button.BUTTON1;
            case ENTER -> Button.BUTTON2;
            default -> null;
        };
    }

}
