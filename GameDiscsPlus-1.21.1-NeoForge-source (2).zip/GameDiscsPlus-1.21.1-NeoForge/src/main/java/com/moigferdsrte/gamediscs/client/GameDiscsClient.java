package com.moigferdsrte.gamediscs.client;

import com.moigferdsrte.gamediscs.item.custom.GamingConsoleItem;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;
import net.neoforged.bus.api.SubscribeEvent;

@EventBusSubscriber(modid = "gamediscs", bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class GameDiscsClient {
    private GameDiscsClient() {}

    @SubscribeEvent
    public static void onClientSetup(FMLClientSetupEvent event) {
        event.enqueueWork(() -> GamingConsoleItem.setScreenOpener(ClientUtils::openConsoleScreen));
    }
}
