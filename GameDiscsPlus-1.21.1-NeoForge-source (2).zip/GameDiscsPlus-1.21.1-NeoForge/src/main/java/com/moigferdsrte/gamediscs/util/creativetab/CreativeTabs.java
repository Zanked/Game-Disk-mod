package com.moigferdsrte.gamediscs.util.creativetab;

import com.moigferdsrte.gamediscs.GameDiscs;
import com.moigferdsrte.gamediscs.item.ItemRegistry;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.minecraft.core.registries.Registries;

public final class CreativeTabs {
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, GameDiscs.MOD_ID);
    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> GAME_DISCS_TAB = TABS.register("game_discs_tab", () -> CreativeModeTab.builder()
        .title(Component.translatable("creativetab.game_discs_tab"))
        .icon(() -> new ItemStack(ItemRegistry.GAMING_CONSOLE.get()))
        .displayItems((parameters, output) -> {
            output.accept(ItemRegistry.GAMING_CONSOLE.get());
            output.accept(ItemRegistry.REDSTONE_CIRCUIT.get()); output.accept(ItemRegistry.PROCESSOR.get());
            output.accept(ItemRegistry.BATTERY.get()); output.accept(ItemRegistry.DISPLAY.get()); output.accept(ItemRegistry.CONTROL_PAD.get());
            output.accept(ItemRegistry.GAME_DISC_FLAPPY_BIRD.get()); output.accept(ItemRegistry.GAME_DISC_SLIME.get());
            output.accept(ItemRegistry.GAME_DISC_BLOCKTRIS.get()); output.accept(ItemRegistry.GAME_DISC_TNT_SWEEPER.get());
            output.accept(ItemRegistry.GAME_DISC_PONG.get()); output.accept(ItemRegistry.GAME_DISC_FROGGIE.get());
            output.accept(ItemRegistry.GAME_DISC_RABBIT.get()); output.accept(ItemRegistry.GAME_DISC_GRID_2048.get());
            output.accept(ItemRegistry.GAME_DISC_GOBANG.get()); output.accept(ItemRegistry.GAME_DISC_GOBANG_AI.get());
            output.accept(ItemRegistry.GAME_DISC_PLANE_WAR.get()); output.accept(ItemRegistry.GAME_DISC_ORE_CRAFTER.get());
            output.accept(ItemRegistry.GAME_DISC_PACMAN.get());
        }).build());
    private CreativeTabs() {}
}
