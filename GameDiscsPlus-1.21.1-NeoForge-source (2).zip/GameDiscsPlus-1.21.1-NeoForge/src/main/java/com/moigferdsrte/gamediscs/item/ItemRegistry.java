package com.moigferdsrte.gamediscs.item;

import com.moigferdsrte.gamediscs.GameDiscs;
import com.moigferdsrte.gamediscs.item.custom.GameDiscItem;
import com.moigferdsrte.gamediscs.item.custom.GamingConsoleItem;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.minecraft.core.registries.Registries;

import java.util.function.Function;

public final class ItemRegistry {
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(GameDiscs.MOD_ID);

    public static final DeferredItem<Item> GAMING_CONSOLE = registerItem("gaming_console", p -> new GamingConsoleItem(p.rarity(Rarity.UNCOMMON)));
    public static final DeferredItem<Item> GAME_DISC_FLAPPY_BIRD = disc("game_disc_flappy_bird", "gamediscs.flappy_bird", ChatFormatting.YELLOW);
    public static final DeferredItem<Item> GAME_DISC_SLIME = disc("game_disc_slime", "gamediscs.slime", ChatFormatting.DARK_GREEN);
    public static final DeferredItem<Item> GAME_DISC_BLOCKTRIS = disc("game_disc_blocktris", "gamediscs.blocktris", ChatFormatting.BLUE);
    public static final DeferredItem<Item> GAME_DISC_TNT_SWEEPER = disc("game_disc_tnt_sweeper", "gamediscs.tnt_sweeper", ChatFormatting.RED);
    public static final DeferredItem<Item> GAME_DISC_PONG = disc("game_disc_pong", "gamediscs.pong_game", ChatFormatting.WHITE);
    public static final DeferredItem<Item> GAME_DISC_FROGGIE = disc("game_disc_froggie", "gamediscs.froggie", ChatFormatting.GREEN);
    public static final DeferredItem<Item> GAME_DISC_RABBIT = disc("game_disc_rabbit", "gamediscs.rabbit", ChatFormatting.GOLD);
    public static final DeferredItem<Item> GAME_DISC_GRID_2048 = disc("game_disc_grid_2048", "gamediscs.grid_2048", ChatFormatting.GRAY);
    public static final DeferredItem<Item> GAME_DISC_GOBANG = disc("game_disc_gobang", "gamediscs.gobang", ChatFormatting.DARK_GRAY);
    public static final DeferredItem<Item> GAME_DISC_GOBANG_AI = disc("game_disc_gobang_ai", "gamediscs.gobang_ai", ChatFormatting.DARK_GRAY);
    public static final DeferredItem<Item> GAME_DISC_PLANE_WAR = disc("game_disc_plane_war", "gamediscs.plane_war", ChatFormatting.DARK_AQUA);
    public static final DeferredItem<Item> GAME_DISC_ORE_CRAFTER = disc("game_disc_ore_crafter", "gamediscs.ore_crafter", ChatFormatting.GOLD);
    public static final DeferredItem<Item> GAME_DISC_PACMAN = disc("game_disc_pacman", "gamediscs.pacman", ChatFormatting.YELLOW);
    public static final DeferredItem<Item> REDSTONE_CIRCUIT = registerItem("redstone_circuit", Item::new);
    public static final DeferredItem<Item> PROCESSOR = registerItem("processor", Item::new);
    public static final DeferredItem<Item> BATTERY = registerItem("battery", Item::new);
    public static final DeferredItem<Item> DISPLAY = registerItem("display", Item::new);
    public static final DeferredItem<Item> CONTROL_PAD = registerItem("control_pad", Item::new);

    private static DeferredItem<Item> disc(String name, String translation, ChatFormatting color) {
        return registerItem(name, p -> new GameDiscItem(p.rarity(Rarity.RARE), Component.translatable(translation).withStyle(color)));
    }
    private static DeferredItem<Item> registerItem(String name, Function<Item.Properties, Item> factory) {
        return ITEMS.register(name, () -> factory.apply(new Item.Properties()));
    }
    private ItemRegistry() {}
}
