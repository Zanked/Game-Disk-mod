package com.moigferdsrte.gamediscs.sounds;

import com.moigferdsrte.gamediscs.GameDiscs;
import net.minecraft.sounds.SoundEvent;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

public final class SoundRegistry {
    public static final DeferredRegister<SoundEvent> SOUNDS = DeferredRegister.create(net.minecraft.core.registries.Registries.SOUND_EVENT, GameDiscs.MOD_ID);
    public static final DeferredHolder<SoundEvent, SoundEvent> JUMP = sound("jump");
    public static final DeferredHolder<SoundEvent, SoundEvent> CLICK = sound("click");
    public static final DeferredHolder<SoundEvent, SoundEvent> POINT = sound("point");
    public static final DeferredHolder<SoundEvent, SoundEvent> NEW_BEST = sound("new_best");
    public static final DeferredHolder<SoundEvent, SoundEvent> GAME_OVER = sound("game_over");
    public static final DeferredHolder<SoundEvent, SoundEvent> SELECT = sound("select");
    public static final DeferredHolder<SoundEvent, SoundEvent> CONFIRM = sound("confirm");
    public static final DeferredHolder<SoundEvent, SoundEvent> EXPLOSION = sound("explosion");
    public static final DeferredHolder<SoundEvent, SoundEvent> SHOOT = sound("shoot");
    public static final DeferredHolder<SoundEvent, SoundEvent> SWING = sound("swing");
    public static final DeferredHolder<SoundEvent, SoundEvent> SWITCH = sound("switch");
    private static DeferredHolder<SoundEvent, SoundEvent> sound(String name) {
        return SOUNDS.register(name, () -> SoundEvent.createVariableRangeEvent(GameDiscs.id(name)));
    }
    private SoundRegistry() {}
}
