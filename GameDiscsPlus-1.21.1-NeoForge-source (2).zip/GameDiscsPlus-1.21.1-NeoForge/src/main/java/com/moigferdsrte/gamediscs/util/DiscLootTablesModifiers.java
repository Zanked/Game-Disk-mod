package com.moigferdsrte.gamediscs.util;

/**
 * Loot integration placeholder for the NeoForge port.
 * Fabric's LootTableEvents callback cannot be used on NeoForge; implement this with
 * NeoForge GlobalLootModifier JSON/code before considering mob/chest drops complete.
 */
public final class DiscLootTablesModifiers {
    private DiscLootTablesModifiers() {}

    public static void modifyLootTables() {
        // Intentionally no-op until the Global Loot Modifier port is implemented.
    }
}
