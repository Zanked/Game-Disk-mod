package com.moigferdsrte.gamediscs.client;

import net.minecraft.client.Minecraft;
import net.minecraft.world.item.Item;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import com.moigferdsrte.gamediscs.client.screen.GamingConsoleScreen;
import com.moigferdsrte.gamediscs.games.gamediscs.*;
import com.moigferdsrte.gamediscs.games.util.Game;
import com.moigferdsrte.gamediscs.item.ItemRegistry;
import com.moigferdsrte.gamediscs.item.custom.GameDiscItem;

import java.util.Map;
import java.util.function.Supplier;

public final class ClientUtils {
    private static final Map<Item, Supplier<Game>> GAMES = Map.ofEntries(
            Map.entry(ItemRegistry.GAME_DISC_FLAPPY_BIRD.get(), FlappyBirdGame::new),
            Map.entry(ItemRegistry.GAME_DISC_SLIME.get(), SlimeGame::new),
            Map.entry(ItemRegistry.GAME_DISC_BLOCKTRIS.get(), BlocktrisGame::new),
            Map.entry(ItemRegistry.GAME_DISC_TNT_SWEEPER.get(), TntSweeperGame::new),
            Map.entry(ItemRegistry.GAME_DISC_PONG.get(), PongGame::new),
            Map.entry(ItemRegistry.GAME_DISC_FROGGIE.get(), FroggieGame::new),
            Map.entry(ItemRegistry.GAME_DISC_RABBIT.get(), RabbitGame::new),
            Map.entry(ItemRegistry.GAME_DISC_GRID_2048.get(), Grid2048Game::new),
            Map.entry(ItemRegistry.GAME_DISC_GOBANG.get(), GobangGamePlayerEdition::new),
            Map.entry(ItemRegistry.GAME_DISC_GOBANG_AI.get(), GobangGameAiEdition::new),
            Map.entry(ItemRegistry.GAME_DISC_PLANE_WAR.get(), PlaneWarGame::new),
            Map.entry(ItemRegistry.GAME_DISC_ORE_CRAFTER.get(), OreCrafterGame::new),
            Map.entry(ItemRegistry.GAME_DISC_PACMAN.get(), PacmanGame::new)
    );

    private ClientUtils() {
    }

    public static void openConsoleScreen() {
        Minecraft.getInstance().setScreen(new GamingConsoleScreen(Component.translatable("gui.gamingconsole.title")));
    }

    public static Game newGameFor(GameDiscItem item) {
        Supplier<Game> sup = GAMES.get(item);
        if (sup == null) {
            throw new IllegalArgumentException("No game specified for " + item + " (" + BuiltInRegistries.ITEM.getKey(item) + ")");
        }
        return sup.get();
    }
}
