package com.moigferdsrte.gamediscs.games.util;

import com.moigferdsrte.gamediscs.client.render.GameGraphics;
import net.minecraft.resources.ResourceLocation;
import com.moigferdsrte.gamediscs.games.math.Vec2f;
import com.moigferdsrte.gamediscs.games.graphics.*;

public class Particle {
    // Properties of the Particle
    private int lifetime;
    public ParticleLevel level;
    private Vec2f pos = Vec2f.ZERO;
    private Vec2f vel = Vec2f.ZERO;
    private Renderer image = new Renderer();
    public Particle(Vec2f pos, ParticleColor color, int lifetime, ParticleLevel level) {
        this.pos = pos;
        this.image = new BasicParticleRenderer(color);
        this.lifetime = lifetime;
        this.level = level;
    }
    public Particle(Vec2f pos, Renderer image, int lifetime, ParticleLevel level) {
        this.pos = pos;
        this.image = image;
        this.lifetime = lifetime;
        this.level = level;
    }
    public Particle(Vec2f pos, ResourceLocation file, int fileWidth, int fileHeight, int lifetime, ParticleLevel level) {
        this.pos = pos;
        this.lifetime = lifetime;
        this.level = level;
        this.image = new BreakParticleRenderer(file, fileWidth, fileHeight);
    }
    public Particle(Vec2f pos, ResourceLocation file, int fileWidth, int fileHeight, int posX, int posY, int width, int height, int lifetime, ParticleLevel level) {
        this.pos = pos;
        this.lifetime = lifetime;
        this.level = level;
        this.image = new ParticleRenderer(file, fileWidth, fileHeight, posX, posY, width, height);
    }

    // getters and setters
    public Vec2f getPos() {
        return pos;
    }
    public float getX() {
        return pos.x;
    }
    public float getY() {
        return pos.y;
    }
    public void setPos(Vec2f pos) {
        this.pos = pos;
    }
    public void moveBy(Vec2f offset) {
        pos = pos.add(offset);
    }
    public Vec2f getVelocity() {
        return vel;
    }
    public void setVelocity(Vec2f vel) {
        this.vel = vel;
    }
    public void addVelocity(Vec2f vel) {
        this.vel = this.vel.add(vel);
    }
    public void tick() {
        this.pos = this.pos.add(this.vel);
        this.lifetime--;
    }

    /**
     * Renders the particle
     * @param graphics GuiGraphics used for rendering
     * @param gameX X position of game
     * @param gameY Y position of game
     */
    public void render(GameGraphics graphics, int gameX, int gameY, GameStage stage) {
        if (level.isFor(stage)) {
            image.render(graphics, gameX + (int) this.pos.x, gameY + (int) this.pos.y);
        }
    }

    public boolean isForOverlay() {
        return level == ParticleLevel.OVERLAY;
    }

    public boolean isDead() {
        return lifetime <= 0;
    }
}
