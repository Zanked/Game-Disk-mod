package com.moigferdsrte.gamediscs.util.networking;

import com.moigferdsrte.gamediscs.GameDiscs;
import com.moigferdsrte.gamediscs.item.custom.GamingConsoleItem;
import com.moigferdsrte.gamediscs.util.networking.payload.SetBestScoreC2SPayload;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;

@EventBusSubscriber(modid = GameDiscs.MOD_ID, bus = EventBusSubscriber.Bus.MOD)
public final class ModMessages {
    private ModMessages() {}

    @SubscribeEvent
    public static void registerPayloads(RegisterPayloadHandlersEvent event) {
        event.registrar("1").playToServer(SetBestScoreC2SPayload.TYPE, SetBestScoreC2SPayload.CODEC,
                (payload, context) -> context.enqueueWork(() -> {
                    var player = context.player();
                    ItemStack stack = player.getMainHandItem();
                    if (!(stack.getItem() instanceof GamingConsoleItem)) {
                        stack = player.getItemInHand(InteractionHand.OFF_HAND);
                    }
                    if (stack.getItem() instanceof GamingConsoleItem console) {
                        console.setBestScore(stack, payload.game(), payload.score(), player);
                    }
                }));
    }
}
