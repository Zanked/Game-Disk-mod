package com.moigferdsrte.gamediscs.item.custom;

import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import java.util.List;

public class GameDiscItem extends Item {
    private final Component name;

    public GameDiscItem(Item.Properties properties, Component name) {
        super(properties.stacksTo(1));
        this.name = name;
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(name);
    }
}
