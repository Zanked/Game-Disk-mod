package com.moigferdsrte.gamediscs;

import com.moigferdsrte.gamediscs.item.ItemRegistry;
import com.moigferdsrte.gamediscs.sounds.SoundRegistry;
import com.moigferdsrte.gamediscs.util.creativetab.CreativeTabs;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Mod(GameDiscs.MOD_ID)
public final class GameDiscs {
    public static final String MOD_ID = "gamediscs";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public GameDiscs(IEventBus modBus) {
        ItemRegistry.ITEMS.register(modBus);
        SoundRegistry.SOUNDS.register(modBus);
        CreativeTabs.TABS.register(modBus);
        LOGGER.info("Initializing {} for NeoForge", MOD_ID);
    }
    public static ResourceLocation id(String path) { return ResourceLocation.fromNamespaceAndPath(MOD_ID, path); }
}
