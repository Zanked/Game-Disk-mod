plugins {
    id("net.neoforged.moddev") version "2.0.107"
    `maven-publish`
}

version = providers.gradleProperty("mod_version").get()
group = providers.gradleProperty("maven_group").get()
base { archivesName = providers.gradleProperty("archives_base_name") }

java {
    toolchain.languageVersion = JavaLanguageVersion.of(21)
    withSourcesJar()
}

neoForge {
    version = "21.1.209"
    runs {
        register("client") { client() }
        register("server") { server(); programArgument("--nogui") }
    }
    mods {
        register("gamediscs") { sourceSet(sourceSets.main.get()) }
    }
}

repositories { mavenCentral() }

tasks.withType<JavaCompile>().configureEach {
    options.encoding = "UTF-8"
    options.release = 21
}

tasks.jar {
    from("LICENSE") { rename { "\${it}_\${project.name}" } }
}
